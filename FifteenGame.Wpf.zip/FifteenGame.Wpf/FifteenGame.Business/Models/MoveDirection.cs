﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FifteenGame.Business.Models
{
    public enum MoveDirection
    {
        None,
        Left,
        Right,
        Up, 
        Down,
    }
}
